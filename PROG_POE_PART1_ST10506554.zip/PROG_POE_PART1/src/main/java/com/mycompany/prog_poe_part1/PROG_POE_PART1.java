/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prog_poe_part1;
import java.util.Scanner;
/**
 *
 * @author enkos
 */
public class PROG_POE_PART1 {

    public static void main(String[] args) {
        Scanner myInput = new Scanner(System.in);
        //Declarations
        String firstName;
        String lastName;
        String cellphoneNumber;
        String username;
        String password;
        String loginusername;
        String loginpassword;
        
        
        System.out.println("Enter your first name: ");
        firstName = myInput.nextLine();
        System.out.println("Enter your last name: ");
        lastName = myInput.nextLine();
        System.out.println("Enter your cellphone number(Cellphone number must start with +27): ");
        cellphoneNumber = myInput.nextLine();
        System.out.println("Enter username(Username must contain an underscore and a maximum of 5 characters): ");
        username = myInput.nextLine();
        System.out.println("Enter password(Password must have a minimum of 8 characters, a capital letter, a number and a special character.): ");
        password = myInput.nextLine();
        
        //Call the method that checks if the username and password have the correct format
        Login login = new Login();
        String message = login.registerUser(username, password);
        System.out.println(message);
        
        //After registration is successful, the user can log in
        System.out.println("Enter username to login: ");
        loginusername = myInput.nextLine();
        System.out.println("Enter your password to login: ");
        loginpassword = myInput.nextLine();
        
        //Call the method that checks if login details match the details saved during registration.
        String status = login.returnLoginStatus(username, password, loginusername, loginpassword);
        System.out.println(status);
    }
}
