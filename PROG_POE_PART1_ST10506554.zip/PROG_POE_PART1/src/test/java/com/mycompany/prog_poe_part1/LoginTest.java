/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.prog_poe_part1;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author enkos
 */
public class LoginTest {
    
    @Test
    public void testUsernameIncorrectFormat() {
        Login login = new Login();
        
        String expected = "{Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
        String actual = login.registerUser("kyle!!!!!!!", "Ch&&sec@ke99!");
        assertEquals(expected, actual, "Expect username error to match kyle!!!!!!!");    
    }
    @Test
    public void testPasswordComplexity() {
        Login login = new Login();
        String expected = "Password successfully captures.";
        String Actual = login.registerUser("ky1_1", "Ch&&sec@ke99!");
        assertEquals(expected, Actual, "Expect password to match for Ch&&sec@k99!");
    }
    @Test
    public void testPasswordNotComplex(){
        Login login = new Login();
        String expected = "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        String Actual = login.registerUser("Ky1_1", "password");
        assertEquals(expected, Actual, "Expect password error to match for password");   
    }
    @Test
    public void testNumberCorrectFormat(){
        Login login = new Login();
        Boolean expected = true;
        Boolean Actual = login.checkCellphoneNumber("+27838968976");
        assertEquals(expected, Actual, "Expert cellphone number to match for +27838968976");     
    }
    @Test
    public void testNumberIncorrectFormat(){
        Login login = new Login();
        String expected = "Cellphone number does does not contain the international code and length is not 12 characters, please correct the number.";
        Boolean Actual = login.checkCellphoneNumber("08966553");
        assertEquals(expected, Actual, "Expect cell error for 08955443");
    }
    @Test
    public void testLoginSuccess(){
        Login login = new Login();
        login.registerUser("ky1_1", "Ch&&sec@ke!");
        boolean Actual = login.loginUser("ky1_1","Ch&&sec@ke99!");
        assertTrue(Actual, "Expext login to be True for the matching details");       
    }
    @Test
    public void testLoginFail(){
        Login login = new Login();
        login.registerUser("ky1_1", "Ch&&sec@ke99!");
        boolean Actual = login.loginUser("ky1_1", "wrongformat");
        assertFalse(Actual, "Expect login to be false for wrong password");
    }
    @Test
    public void testCorrectUsername(){
        Login login = new Login();
        boolean Actual = login.checkUserName("ky1_1");
        assertTrue(Actual, "Expert username is correctly formatted to be true for ky1_1");
    }
    @Test
    public void testIncorrectUsername(){
        Login login = new Login();
        boolean Actual = login.checkUserName("kyle!!!!!!!");
        assertFalse(Actual, "Expect username incorrectly formatted to be false for kyle!!!!!!!");      
    }
    @Test
    public void testCorrectNumber(){
        Login login = new Login();
        boolean Actual = login.checkCellphoneNumber("+27838968976");
        assertTrue(Actual, "Expect cellphone number is correctly formatted to be true for +27838968976");
}
    @Test
    public void testIncorrectNumber(){
        Login login = new Login();
        boolean Actual = login.checkCellphoneNumber("08966553");
        assertFalse(Actual, "Expert cell incorrectly formatted to be False for 08966553");
    }
}
