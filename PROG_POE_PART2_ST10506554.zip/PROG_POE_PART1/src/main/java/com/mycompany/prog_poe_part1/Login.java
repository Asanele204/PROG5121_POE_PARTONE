/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prog_poe_part1;
import java.util.Scanner;
/**
 *
 * @author enkos
 */
public class Login {
    //Declarations
   public String savedUsername;
   public String savedPassword;
   public String firstName;
   public String lastName;
    private Object password;
    
    public String registerUser(String username, String password) {
       //check if username format is correct
       if (!checkUserName(username)) {
           return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.";
       }
       if (!checkPasswordComplexity(password)){
         return "Password is not correctly formatted, please ensure that the password contains at least eight characters, a capital letter, a number, and a special character." ; 
       }
       //If both the username and password are correctly formatted, save them
       this.savedUsername = username;
       this.savedPassword = password;
       this.firstName = firstName;
       this.lastName = lastName;
       
       //Show that registration has been successful
       return "The username and password conditions have been met and you are successfully registered.";   
    }
   
    //A method that checks if username format is correct
    public boolean checkUserName(String username){
        if (username.contains ("_") && username.length() <= 5) {
            return true;
        }
        else {
            return false;
        }
    }
    
    //A method that checks if password format is correct
    public boolean checkPasswordComplexity(String password) {
        if (password.length() < 8){
            return false;
        }
        boolean haveCapital = ! password.equals(password.toLowerCase());
        boolean haveNumber = password.matches(".*\\d.*");
        boolean haveSpecialChar = password.matches(".*[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>\\/?].*");
        
        return haveCapital && haveNumber && haveSpecialChar;
    }
    
    //A method that checks if the cellphone number format is correct
    public boolean checkCellphoneNumber(String cellphoneNumber){
        if (cellphoneNumber.startsWith("+27") && cellphoneNumber.length() == 12){
        return true;
    } else {
          return  false;
        }
    }
        
        //POE PART TWO
        //Login and check if the login was successful
        
        public boolean loginUser(String username, String enteredUsername) {
       Object enteredPassword = null;
            //The method returns true if both details match
            if (username.equals(enteredUsername) && password.equals(enteredPassword)) {
                return true;
            }
            else {
                return false;
            }
        }
        
        public String returnLoginStatus(String firstName, String lastName, boolean isLoggedIn){
            if (isLoggedIn){
                return "Welcome to QuickChat";
            }
            else {
                return "Username or password is incorrect, try again";
            }
        }
        
    
}
