/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prog_poe_part1;
import javax.swing.JOptionPane;
import java.util.Random;
import java.util.Scanner;
import java.util.ArrayList;
import java.io.FileWriter;
/**
 *
 * @author enkos
 */
       public class Messages {
              //A method that stores messages that the user sent
    private String messageID;
    public int messageCount = 0;
    private ArrayList<String> allSentDetails = new ArrayList<>();

    // A method creating arrays
    public String[] messageIDs = new String[100];
    public String[] recipients = new String[100];
    public String[] messages = new String[100];
    public String[] messageHashes = new String[100];
    public String[] hashes = new String[100]; 

    public String generateMessageID() {
        Random rand = new Random();
        long number = 1000000000L + (long)(rand.nextDouble() * 9000000000L);
        messageID = String.valueOf(number);
        return messageID;
    }

    public String createMessageID() {
        return generateMessageID();
    }

    public String getMessageIDGenerated() {
        return "Message ID generated: " + messageID;
    }

    public boolean checkMessageID(String id) {
        return id.length() <= 10;
    }

    public String checkMessageLength(String message) {
        if (message.length() <= 250) {
            return "Message ready to send.";
        } else {
            int over = message.length() - 250;
            return "Message exceeds 250 characters by " + over + ", please reduce the size.";
        }
    }

    public String checkRecipientCell(String cell) {
        if (cell.length() <= 10 && cell.contains("+")) {
            return "Cell phone number successfully captured.";
        } else {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
    }

    public String createMessageHash(String msgID, int msgNumber, String message) {
        String firstTwo = msgID.substring(0, 2);
        String[] words = message.trim().split("\\s+");
        String first = words[0].replaceAll("[^a-zA-Z]", "");
        String last = words[words.length - 1].replaceAll("[^a-zA-Z]", "");
        String hash = (firstTwo + ":" + msgNumber + ":" + (first + last)).toUpperCase();
        // store messages in arrays
        if (messageCount < 100) {
            messageHashes[messageCount] = hash;
            hashes[messageCount] = hash;
        }
        return hash;
    }

    public String SentMessage(String choice) {
        if (choice.equals("1") || choice.equalsIgnoreCase("Send Message")) {
            return "Message successfully sent.";
        } else if (choice.equals("2") || choice.equalsIgnoreCase("Disregard Message")) {
            return "Press 0 to delete the message.";
        } else if (choice.equals("3") || choice.equalsIgnoreCase("Store Message")) {
            return "Message successfully stored.";
        } else {
            return "Invalid choice";
        }
    }

    public int returnTotalMessages() {
        return messageCount;
    }

    public int returnTotalMessagess() {
        return messageCount;
    }

    public String printMessages() {
        String out = "";
        int i = 0;
        while (i < messageCount) {
            out += messageHashes[i] + " to " + recipients[i] + ": " + messages[i] + "\n";
            i++;
        }
        return out;
    }
       }
