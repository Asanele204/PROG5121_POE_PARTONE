/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prog_poe_part1;

/**
 *
 * @author enkos
 */
public class PROG_POE_PART1 {

    public static void main(String[] args) {
    }
}
