/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prog_poe_part1;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author enkos
 */
public class MessagesTest {
     Messages msg = new Messages();

    String recipient1 = "+27718693002";
    String message1 = "Hi Mike, can you join us for dinner tonight?";
    String recipient2 = "08575975889";
    String message2 = "Hi Keegan, did you receive the payment?";

    @Test
    public void testMessageNotMoreThan250_Success() {
        assertEquals("Message ready to send.", msg.checkMessageLength(message1));
    }

    @Test
    public void testMessageNotMoreThan250_Failure() {
        String longMsg = "a".repeat(260);
        String result = msg.checkMessageLength(longMsg);
        assertEquals("Message exceeds 250 characters by 10, please reduce the size.", result);
    }

    @Test
    public void testRecipientCorrectlyFormatted_Success() {
        assertEquals("Cell phone number successfully captured.", msg.checkRecipientCell(recipient1));
    }

    @Test
    public void testRecipientCorrectlyFormatted_Failure() {
        assertEquals("Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.", msg.checkRecipientCell(recipient2));
    }

    @Test
    public void testMessageHashIsCorrect() {
        String testID = "0012345678";
        String hash = msg.createMessageHash(testID, 0, message1);
        assertEquals("00:0:HITONIGHT", hash);
    }

    @Test
    public void testMessageIDIsCreated() {
        String id = msg.createMessageID();
        assertTrue(msg.checkMessageID(id));
        assertEquals(10, id.length());
        assertTrue(msg.getMessageIDGenerated().startsWith("Message ID generated: "));
    }

    @Test
    public void testMessageSent_AllThreeOptions() {
        assertEquals("Message successfully sent.", msg.SentMessage("1"));
        assertEquals("Press 0 to delete the message.", msg.SentMessage("2"));
        assertEquals("Message successfully stored.", msg.SentMessage("3"));
    }

    @Test
    public void testReturnTotalMessages() {
        msg.messageIDs[0] = "0012345678";
        msg.recipients[0] = recipient1;
        msg.messages[0] = message1;
        msg.messageHashes[0] = "00:0:HITONIGHT";
        msg.messageCount = 1;
        assertEquals(1, msg.returnTotalMessages());
    }

    @Test
    public void testPrintMessages() {
        msg.messageIDs[0] = "0012345678";
        msg.recipients[0] = recipient1;
        msg.messages[0] = message1;
        msg.messageHashes[0] = "00:0:HITONIGHT";
        msg.messageCount = 1;
        String print = msg.printMessages();
        assertTrue(print.contains("+27718693002"));
    }

    @Test
    public void testMessageHashesInLoop() {
        String[] testMessages = {message1, message2};
        int i = 0;
        while (i < testMessages.length) {
            String id = msg.createMessageID();
            String hash = msg.createMessageHash(id, i, testMessages[i]);
            assertNotNull(hash);
            i++;
        }
    }
     
}
