/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prog_poe_part1;
import javax.swing.JOptionPane;
import java.util.Random;
import java.util.Scanner;
import java.util.ArrayList;
import java.io.FileWriter;
/**
 *
 * @author enkos
 */
       public class Messages {
              //A method that stores messages that the user sent
    private String messageID;
    public int messageCount = 0;
    private ArrayList<String> allSentDetails = new ArrayList<>();

    // A method creating arrays
    public String[] messageIDs = new String[100];
    public String[] recipients = new String[100];
    public String[] messages = new String[100];
    public String[] messageHashes = new String[100];
    public String[] hashes = new String[100];
    public String[] senders = new String[100];
    public String[] storedMessages = new String[100];
    public String[] storedSenders = new String[100];
    public String[] storedRecipients = new String[100];
    public String[] storedIDs = new String[100];
    public String[] storedHashes = new String[100];
    public int storedCount = 0;
    public int sentCount = 0;
    public int disregardedCount = 0;

    public String generateMessageID() {
        Random rand = new Random();
        long number = 1000000000L + (long)(rand.nextDouble() * 9000000000L);
        messageID = String.valueOf(number);
        return messageID;
    }

    public String createMessageID() {
        return generateMessageID();
    }

    public String getMessageIDGenerated() {
        return "Message ID generated: " + messageID;
    }

    public boolean checkMessageID(String id) {
        return id.length() <= 10;
    }

    public String checkMessageLength(String message) {
        if (message.length() <= 250) {
            return "Message ready to send.";
        } else {
            int over = message.length() - 250;
            return "Message exceeds 250 characters by " + over + ", please reduce the size.";
        }
    }

    public String checkRecipientCell(String cell) {
        if (cell.length() <= 10 && cell.contains("+")) {
            return "Cell phone number successfully captured.";
        } else {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
    }

    public String createMessageHash(String msgID, int msgNumber, String message) {
        String firstTwo = msgID.substring(0, 2);
        String[] words = message.trim().split("\\s+");
        String first = words[0].replaceAll("[^a-zA-Z]", "");
        String last = words[words.length - 1].replaceAll("[^a-zA-Z]", "");
        String hash = (firstTwo + ":" + msgNumber + ":" + (first + last)).toUpperCase();
        // store messages in arrays
        if (messageCount < 100) {
            messageHashes[messageCount] = hash;
            hashes[messageCount] = hash;
        }
        return hash;
    }

    public String SentMessage(String choice) {
        if (choice.equals("1") || choice.equalsIgnoreCase("Send Message")) {
            return "Message successfully sent.";
        } else if (choice.equals("2") || choice.equalsIgnoreCase("Disregard Message")) {
            return "Press 0 to delete the message.";
        } else if (choice.equals("3") || choice.equalsIgnoreCase("Store Message")) {
            return "Message successfully stored.";
        } else {
            return "Invalid choice";
        }
    }

    public int returnTotalMessages() {
        return messageCount;
    }

    public String printMessages() {
        String out = "";
        int i = 0;
        while (i < messageCount) {
            out += messageHashes[i] + " to " + recipients[i] + ": " + messages[i] + "\n";
            i++;
        }
        return out;
    }
    
    //POE PART THREE
    
    // Save messages into arrays
public void addMessage(String sender, String recipient, String message, String flag) {
    String id = generateMessageID();
    String hash = createMessageHash(id, messageCount, message);

    // Arrays
    senders[messageCount] = sender;
    recipients[messageCount] = recipient;
    messages[messageCount] = message;
    messageIDs[messageCount] = id;
    messageHashes[messageCount] = hash;
    messageCount++;

    if (flag.equalsIgnoreCase("Send") || flag.equalsIgnoreCase("1") || flag.equalsIgnoreCase("Send Message")) {
        sentCount++;
    } else if (flag.equalsIgnoreCase("Store") || flag.equalsIgnoreCase("3") || flag.equalsIgnoreCase("Store Message")) {
        storedMessages[storedCount] = message;
        storedSenders[storedCount] = sender;
        storedRecipients[storedCount] = recipient;
        storedIDs[storedCount] = id;
        storedHashes[storedCount] = hash;
        storedCount++;
        saveStoredMessagesToJSON();
    } else if (flag.equalsIgnoreCase("Disregard") || flag.equalsIgnoreCase("2") || flag.equalsIgnoreCase("Disregard Message")) {
        disregardedCount++;
    }
}

// The messages that will be used for test data
public void populateTestData() {
    addMessage("0838884567", "+27834557896", "Did you get the cake?", "Sent");
    addMessage("0838884567", "+27838884567", "Where are you? You are late! I have asked you to be on time.", "Stored");
    addMessage("0838884567", "+27834484567", "Yohoooo, I am at your gate.", "Disregard");
    addMessage("0838884567", "0838884567", "It is dinner time !", "Sent");
    addMessage("0838884567", "+27838884567", "Ok, I am leaving without you.", "Stored");
}

// a. Display the sender and recipient of all stored messages
public String displaySenderRecipient() {
    String out = "";
    for (int i = 0; i < storedCount; i++) {
        out += "Sender: " + storedSenders[i] + ", Recipient: " + storedRecipients[i] + "\n";
    }
    if (out.equals("")) return "No stored messages.";
    return out;
}

// b. Display the longest message stored
public String displayLongestStored() {
    if (storedCount == 0) return "No stored messages.";
    String longest = storedMessages[0];
    for (int i = 1; i < storedCount; i++) {
        if (storedMessages[i].length() > longest.length()) longest = storedMessages[i];
    }
    return longest;
}

// c. Search by ID display corresponding recipient and message
public String searchByID(String searchID) {
    for (int i = 0; i < messageCount; i++) {
        if (messageIDs[i].equals(searchID)) {
            return "Recipient: " + recipients[i] + "\nMessage: " + messages[i];
        }
    }
    return "Message ID not found.";
}

// d. Search for all messages stored by a particular recipient
public String searchByRecipient(String searchRec) {
    String out = "";
    for (int i = 0; i < messageCount; i++) {
        if (recipients[i].equals(searchRec)) {
            out += messages[i] + "\n";
        }
    }
    if (out.equals("")) return "No messages for that recipient.";
    return out;
}

// e. Delete a message using the Hash
public String deleteByHash(String hash) {
    for (int i = 0; i < storedCount; i++) {
        if (storedHashes[i].equals(hash)) {
            for (int j = i; j < storedCount - 1; j++) {
                storedMessages[j] = storedMessages[j+1];
                storedSenders[j] = storedSenders[j+1];
                storedRecipients[j] = storedRecipients[j+1];
                storedIDs[j] = storedIDs[j+1];
                storedHashes[j] = storedHashes[j+1];
            }
            storedCount--;
            saveStoredMessagesToJSON();
            return "Message: \" " + storedMessages + "\"successfully deleted.";
        }
    }
    return "Hash not found.";
}

// f. Display a report that lists the full details of all the stored messages
public String displayFullReport() {
    String out = "";
    for (int i = 0; i < messageCount; i++) {
        out += "ID: " + messageIDs[i] + "\nHash: " + messageHashes[i]
             + "\nSender: " + storedSenders[i]
             + "\nRecipient: " + recipients[i]
             + "\nMessage: " + messages[i] + "\n\n";
    }
    if (out.equals("")) return "No messages.";
    return out;
}

// JSON Save
public void saveStoredMessagesToJSON() {
    try {
        java.io.FileWriter writer = new java.io.FileWriter("storedMessages.json");
        writer.write("[\n");
        for (int i = 0; i < storedCount; i++) {
            writer.write("{\"id\":\"" + storedIDs[i] + "\",\"sender\":\"" + storedSenders[i] + "\",\"recipient\":\"" + storedRecipients[i] + "\",\"message\":\"" + storedMessages[i] + "\",\"hash\":\"" + storedHashes[i] + "\"}");
            if (i < storedCount - 1) writer.write(",\n");
        }
        writer.write("\n]");
        writer.close();
    } catch (Exception e) {
        System.out.println("Could not save: " + e.getMessage());
    }
}

public void loadStoredMessagesFromJSON() {
    try {
        java.io.BufferedReader br = new java.io.BufferedReader(new java.io.FileReader("storedMessages.json"));
        String line; String content = "";
        while ((line = br.readLine()) != null) content += line;
        br.close();
        if (content.contains("\"id\"")) {
            String[] objects = content.split("\\{");
            for (String obj : objects) {
                if (!obj.contains("id")) continue;
                String id = obj.split("\"id\":\"")[1].split("\"")[0];
                String sender = obj.split("\"sender\":\"")[1].split("\"")[0];
                String recipient = obj.split("\"recipient\":\"")[1].split("\"")[0];
                String message = obj.split("\"message\":\"")[1].split("\"")[0];
                String hash = obj.split("\"hash\":\"")[1].split("\"")[0];
                storedMessages[storedCount] = message;
                storedSenders[storedCount] = sender;
                storedRecipients[storedCount] = recipient;
                storedIDs[storedCount] = id;
                storedHashes[storedCount] = hash;
                storedCount++;
            }
        }
    } catch (Exception e) {
        System.out.println("No stored file found - starting fresh");
    }
       }
       }
