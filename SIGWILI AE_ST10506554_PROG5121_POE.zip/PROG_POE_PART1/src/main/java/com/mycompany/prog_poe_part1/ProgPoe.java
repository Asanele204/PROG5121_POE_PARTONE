/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prog_poe_part1;
import javax.swing.JOptionPane;
/**
 *
 * @author enkos
 */
public class ProgPoe {
      public static void main(String[] args) {
        Login login = new Login();
        Messages msg = new Messages();
       
        msg.loadStoredMessagesFromJSON();

        String username = JOptionPane.showInputDialog("Enter username");
        String password = JOptionPane.showInputDialog("Enter password");
        String firstName = JOptionPane.showInputDialog("Enter first name");
        String lastName = JOptionPane.showInputDialog("Enter last name");
       
        JOptionPane.showMessageDialog(null, login.registerUser(username, password));
       
        String loginUser = JOptionPane.showInputDialog("Login - Enter username");
        String loginPass = JOptionPane.showInputDialog("Login - Enter password");
        boolean loggedIn = login.loginUser(loginUser, loginPass);
       
        if (!loggedIn) {
            JOptionPane.showMessageDialog(null, "Login failed. Goodbye.");
            return;
        }
        JOptionPane.showMessageDialog(null, "Welcome " + firstName + " " + lastName);

        boolean running = true;
        while (running) {
            String menu = JOptionPane.showInputDialog(
                "Main Menu\n" +
                "1. Send Messages\n" +
                "2. Show Recently Sent Messages\n" +
                "3. Quit\n" +
                "4. Stored Messages");
           
            if (menu == null) break;
            int choice = Integer.parseInt(menu);

            switch (choice) {
                case 1:
                    String num = JOptionPane.showInputDialog("How many messages?");
                    int howMany = Integer.parseInt(num);
                    for (int i = 0; i < howMany; i++) {
                        String recipient = JOptionPane.showInputDialog("Enter recipient e.g. +27834557896");
                        String message = JOptionPane.showInputDialog("Enter message");
                        String id = msg.generateMessageID();
                    }
                    break;
                case 2:
                    JOptionPane.showMessageDialog(null, msg.printMessages());
                    break;
                case 3:
                    running = false;
                    JOptionPane.showMessageDialog(null, "Total messages: " + msg.returnTotalMessages());
                    break;
                case 4:
                    String sub = JOptionPane.showInputDialog(
                        "Stored Messages\n" +
                        "a. Sender & Recipient\n" +
                        "b. Longest\n" +
                        "c. Search by ID\n" +
                        "d. Search by Recipient\n" +
                        "e. Delete by Hash\n" +
                        "f. Full Report");
                    if (sub == null) break;
                    switch (sub.toLowerCase()) {
                        case "a": JOptionPane.showMessageDialog(null, msg.displaySenderRecipient()); break;
                        case "b": JOptionPane.showMessageDialog(null, msg.displayLongestStored()); break;
                        case "c":
                            String sid = JOptionPane.showInputDialog("Enter Message ID");
                            JOptionPane.showMessageDialog(null, msg.searchByID(sid)); break;
                        case "d":
                            String srec = JOptionPane.showInputDialog("Enter Recipient");
                            JOptionPane.showMessageDialog(null, msg.searchByRecipient(srec)); break;
                        case "e":
                            String shash = JOptionPane.showInputDialog("Enter Hash");
                            JOptionPane.showMessageDialog(null, msg.deleteByHash(shash)); break;
                        case "f": JOptionPane.showMessageDialog(null, msg.displayFullReport()); break;
                    }
                    break;
            }
        }
    }
    
}
