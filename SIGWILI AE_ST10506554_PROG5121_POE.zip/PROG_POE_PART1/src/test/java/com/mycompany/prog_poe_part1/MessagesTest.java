/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prog_poe_part1;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author enkos
 */
public class MessagesTest {
     Messages msg = new Messages();
     
      @Test
    public void testSentMessagesArrayCorrectlyPopulated() {
        Messages msg = new Messages();
        msg.populateTestData();

        String sent = "";
        for (int i = 0; i < msg.messageCount; i++) {
            sent += msg.messages[i] + "|";
        }
        assertTrue(sent.contains("Did you get the cake?"));
        assertTrue(sent.contains("It is dinner time !"));
    }
     
       @Test
    public void testDisplayLongestMessage() {
        Messages msg = new Messages();
        msg.populateTestData();

        String expected = "Where are you? You are late! I have asked you to be on time.";
        String actual = msg.displayLongestStored();
        assertEquals(expected, actual);
    }

    @Test
    public void testSearchForMessageID() {
        Messages msg = new Messages();
        msg.populateTestData();

        String idForMessage4 = msg.messageIDs[3];
        String result = msg.searchByID(idForMessage4);

        assertTrue(result.contains("It is dinner time!") || result.contains("It is dinner time !"));
    }

    @Test
    public void testSearchAllMessagesForRecipient() {
        Messages msg = new Messages();
        msg.populateTestData();

        String result = msg.searchByRecipient("+27838884567");

        assertTrue(result.contains("Where are you? You are late! I have asked you to be on time."));
        assertTrue(result.contains("Ok, I am leaving without you."));
    }

    @Test
    public void testDeleteMessageUsingHash() {
        Messages msg = new Messages();
        msg.populateTestData();

        String hashForMessage2 = msg.storedHashes[0];
        String result = msg.deleteByHash(hashForMessage2);

        String expected = "Message: \"Where are you? You are late! I have asked you to be on time.\" successfully deleted.";
        assertEquals(expected, result);
    }

    @Test
    public void testDisplayReport() {
        Messages msg = new Messages();
        msg.populateTestData();

        String report = msg.displayFullReport();

        assertTrue(report.contains("Hash:"));
        assertTrue(report.contains("Recipient:"));
        assertTrue(report.contains("Message:"));
        assertTrue(report.contains("Did you get the cake?"));
    }
     
}
